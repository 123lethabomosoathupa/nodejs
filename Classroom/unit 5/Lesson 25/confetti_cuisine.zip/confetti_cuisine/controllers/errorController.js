"use strict";

const httpStatus = require("http-status-codes");

module.exports = {
  // === 404 Page Not Found ===
  pageNotFoundError: (req, res) => {
    const errorCode = httpStatus.NOT_FOUND;
    res.status(errorCode);
    // Render a 404 view if you have one
    res.render("404", {
      title: "Page Not Found",
      message: "Sorry, the page you are looking for does not exist."
    });
  },

  // === 500 Internal Server Error ===
  internalServerError: (err, req, res, next) => {
    const errorCode = httpStatus.INTERNAL_SERVER_ERROR;
    console.error(`ERROR occurred: ${err.stack}`);
    res.status(errorCode);
    // Render a 500 view if you have one
    res.render("500", {
      title: "Internal Server Error",
      message: "Sorry, our application is experiencing a problem."
    });
  }
};
