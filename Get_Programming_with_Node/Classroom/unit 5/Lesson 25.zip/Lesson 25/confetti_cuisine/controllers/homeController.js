"use strict";

// Example static course data (optional)
let courses = [
  { title: "Event Driven Cakes", cost: 50 },
  { title: "Asynchronous Artichoke", cost: 25 },
  { title: "Object Oriented Orange Juice", cost: 10 }
];

module.exports = {
  // === Home page ===
  index: (req, res) => {
    res.render("index");
  },

  // === Show courses page ===
  showCourses: (req, res) => {
    res.render("courses", { offeredCourses: courses });
  },

  // === Show signup/contact page ===
  showSignUp: (req, res) => {
    res.render("contact");
  },

  // === Process signup form ===
  postedSignUpForm: (req, res) => {
    res.render("thanks");
  }
};
