// router.js
const httpStatus = require("http-status-codes");
const contentTypes = require("./contentTypes");
const utils = require("./utils");

const routes = { "GET": {}, "POST": {} };

exports.handle = (req, res) => {
  try {
    // exact-match routing only (no querystring or param parsing)
    routes[req.method][req.url](req, res);
  } catch (e) {
    // fallback -> error page
    res.writeHead(httpStatus.OK, contentTypes.html);
    utils.getFile("views/error.html", res);
  }
};

exports.get = (url, action) => {
  routes["GET"][url] = action;
};

exports.post = (url, action) => {
  routes["POST"][url] = action;
};